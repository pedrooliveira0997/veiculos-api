package br.edu.unichristus.veiculos;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "TB_MARCAS")
public class Marca {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MARCA_ID")
	private Long marcaID;

	@Column(name = "NOME", nullable = false, length = 20)
	@NotNull
	private String nome;

	
	@OneToMany(mappedBy="marcas", fetch = FetchType.EAGER)
	private List<Veiculo> veiculos ;

	public Marca() {
	}

	public Marca(String nome, List<Veiculo> veiculos) {
		super();
		this.nome = nome;
		this.veiculos = veiculos;
	}

	@Override
	public String toString() {
		return "Marca [marcaID=" + marcaID + ", nome=" + nome + ", veiculos=" + veiculos + "]";
	}


	


	
	

}
