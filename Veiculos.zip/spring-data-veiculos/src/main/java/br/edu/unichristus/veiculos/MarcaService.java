package br.edu.unichristus.veiculos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.unichristus.veiculos.Marca;
import br.edu.unichristus.veiculos.MarcaRepository;

@Service
public class MarcaService {
	
	@Autowired
	private MarcaRepository repo;
	
	public void salvar(Marca marca) {
		this.repo.save(marca);
	}
	
	//public Marca buscarPeloNome(String nome) {
	//	return this.repo.findByNome(nome);
	//}
	
	public List<Marca> buscarTodas() {
		return this.repo.findAll();
	}
	
	//public List<Marca> buscarTodas() {
	//	return this.repo.findAll();
	//}
	
	//public void remover(Marca marca) {
	//	this.repo.delete(marca);
	//}
	
	//public List <Marca> buscarPelaMarca(Marca marca){
	//	this.repo.findByMarca(marca);
	//}
		
	
	//public List<Editora> buscarPelaCidade(String cidade) {
	//	return this.repo.findByCidade(cidade);
	//}
	
	//public List<Editora> buscarPeloNomeIniciandoEmAouB(String a, String b) {
	//	return this.repo.findByNomeStartingWithOrNomeStartingWith(a, b);
	//}
	
	//public List<Editora> buscarPelasCidadesAouB(String cidade1, String cidade2) {
	//	return this.repo.findByCidadeEqualsOrCidadeEquals(cidade1, cidade2);
	//}

}
