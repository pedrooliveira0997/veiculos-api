package br.edu.unichristus.veiculos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.unichristus.veiculos.Marca;

public interface MarcaRepository extends JpaRepository<Marca, Long> {
	
	public Marca findByNome(String nome);
	
	public List<Marca> findAll();
	
	//public List <Marca> findByMarca(Marca marca);
	
	
	
	
	//public List<Marca> findByCidadeEqualsOrCidadeEquals(String cidade1, String cidade2);
	

}
