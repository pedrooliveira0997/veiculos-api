/*insert into tb_marcas(marca_id, nome_marca) values (1,'Chevrolet');
insert into tb_marcas(marca_id, nome_marca) values (2,'Fiat');
insert into tb_marcas(marca_id, nome_marca) values (3,'Ford');
insert into tb_marcas(marca_id, nome_marca) values (4,'Citroen');

insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (1, 2011, 'AAA-1111', 1);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (2, 2010, 'BBB-2222', 1);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (3, 2013, 'CCC-3333', 2);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (4, 2014, 'DDD-4444', 3);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (5, 2015, 'EEE-5555', 3);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (6, 2010, 'FFF-6666', 3);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (7, 2016, 'GGG-7777', 1);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (8, 2012, 'HHH-8888', 2);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (9, 2009, 'III-9999', 2);
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo, marca_id) values (10, 2014, 'JJJ-1010', 1); */

insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (1, 2011, 'AAA-1111');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (2, 2010, 'BBB-2222');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (3, 2013, 'CCC-3333');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (4, 2014, 'DDD-4444');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (5, 2015, 'EEE-5555');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (6, 2010, 'FFF-6666');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (7, 2016, 'GGG-7777');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (8, 2012, 'HHH-8888');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (9, 2009, 'III-9999');
insert into tb_veiculos(veiculo_id, ano_veiculo, placas_veiculo) values (10, 2014, 'JJJ-1010');

